export class MenuItem {
  constructor( public display:string,
               public route:string,
               public visible:boolean)
  {}
}
