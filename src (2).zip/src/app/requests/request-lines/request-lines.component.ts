import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-lines',
  templateUrl: './request-lines.component.html',
  styleUrls: ['./request-lines.component.css']
})
export class RequestLinesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
